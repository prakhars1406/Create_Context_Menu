﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace EditRegistry
{
    class Program
    {
        //This function will add registry entry in *\shell\AssignmentExplorer
        static void CreateRegEntyForFile(string CurrentPath)
        {
            try
            {
                RegistryKey key = Registry.ClassesRoot.OpenSubKey(@"*\shell", true);
                //create a new key 
                key.CreateSubKey("AssignmentExplorer");
                key.CreateSubKey("AssignmentExplorer\\command");
                key.Close();
                //Edit already existing value
                RegistryKey key3 = Registry.ClassesRoot.OpenSubKey(@"*\shell\AssignmentExplorer", true);
                key3.SetValue(null, "Assignment Explorer");
                key3.Close();
                //Add the path of exe to *\shell\AssignmentExplorer\\command
                RegistryKey key4 = Registry.ClassesRoot.OpenSubKey(@"*\shell\AssignmentExplorer\\command", true);
                key4.SetValue(null, CurrentPath + "\\ContextMenuWindow.exe" + " \"%1\"");
                key4.Close();
            }
            catch(Exception e)
            {
                Console.WriteLine("Exception in CreateRegEntyForFile.Please try to run as admin " + e.Message);
                Console.ReadKey();
            }
            
        }
        //This function willa add registry entry in *\shell\AssignmentExplorer
        static void CreateRegEntyForFolder(string CurrentPath)
        {
            try
            {
                //Create context menu entry for folder
                RegistryKey key2 = Registry.ClassesRoot.OpenSubKey(@"Directory\shell\", true);
                //create a new key 
                key2.CreateSubKey("AssignmentExplorer");
                key2.CreateSubKey("AssignmentExplorer\\command");
                key2.Close();
                //Edit already existing value
                RegistryKey key3 = Registry.ClassesRoot.OpenSubKey(@"Directory\shell\AssignmentExplorer", true);
                key3.SetValue(null, "Assignment Explorer");
                key3.Close();
                //Add the path of exe to *\shell\AssignmentExplorer\\command
                RegistryKey key4 = Registry.ClassesRoot.OpenSubKey(@"Directory\shell\AssignmentExplorer\\command", true);
                key4.SetValue(null, CurrentPath + "\\ContextMenuWindow.exe" + " \"%1\"");
                key4.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception in CreateRegEntyForFolder.Please try to run as admin " + e.Message);
                Console.ReadKey();
            }
        }

        static void Main(string[] args)
        {
            try
            {
                string CurrentPath=Environment.CurrentDirectory;
                CreateRegEntyForFile(CurrentPath);
                CreateRegEntyForFolder(CurrentPath);
                Console.WriteLine(CurrentPath);
                Console.ReadKey();
            }
           catch(Exception e)
            {
                Console.WriteLine("Exception in creating registry.Please try to run as admin "+e.Message);
                Console.ReadKey();
            }


        }
    }
}
