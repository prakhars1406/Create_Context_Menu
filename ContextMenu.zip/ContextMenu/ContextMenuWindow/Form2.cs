﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ContextMenuWindow
{
    public partial class Form2 : Form
    {
        public Form2(string Path)
        {
            InitializeComponent();
            string Filename = Path.Substring(Path.LastIndexOf('\\') + 1);
            label4.Text = Filename;
              int fCount = Directory.GetFiles(Path, "*", SearchOption.TopDirectoryOnly).Length;
            //int fCount = Directory.GetFiles(Path, "*", SearchOption.AllDirectories).Length;
            label5.Text = fCount.ToString();
            DirectoryInfo d = new DirectoryInfo(Path);//Assuming Test is your Folder
            FileInfo[] Files = d.GetFiles("*.*"); //Getting Text files
            foreach (FileInfo file in Files)
            {
                listBox1.Items.Add(file.Name);
            }


        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}
