﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ContextMenuWindow
{
    public partial class Form1 : Form
    {
        string FileOrFolderPath = "";
        public Form1(string Path)
        {
            InitializeComponent();
            ///check path is file or folder.
            FileOrFolderPath = Path;
            long length = new System.IO.FileInfo(Path).Length;
            label6.Text = length.ToString() + " Bytes";
            //getting metatdat of file
            DateTime date_time = File.GetCreationTime(Path);
            label5.Text = date_time.ToString();
            DateTime LastModifies = File.GetLastWriteTime(Path);
            label8.Text = LastModifies.ToString();
            string user = System.IO.File.GetAccessControl(Path).GetOwner(typeof(System.Security.Principal.NTAccount)).ToString();
            label10.Text = user;
            string Filename = Path.Substring(Path.LastIndexOf('\\') + 1);
            label4.Text = Filename;


        }
    }
}
