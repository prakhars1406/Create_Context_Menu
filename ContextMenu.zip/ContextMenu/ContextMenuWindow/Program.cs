﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ContextMenuWindow
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] arguments)
        {
            string folderpath = "";
            if (arguments.Length > 0)//If an argument has been passed.
            {
                folderpath = arguments[0];
            }
            FileAttributes attr = File.GetAttributes(folderpath);

            if (attr.HasFlag(FileAttributes.Directory))
            {
                MessageBox.Show("Its a directory");
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new Form2(folderpath));
            }
            else
            {
                MessageBox.Show("Its a file");
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new Form1(folderpath));
            }
        }
    }
}
